﻿using System;
using System.Collections.Generic;
using System.Text;

namespace congestion.calculator
{
    public class Military : IVehicle
    {
        public string GetVehicleType()
        {
            return "Military";
        }
    }
}
