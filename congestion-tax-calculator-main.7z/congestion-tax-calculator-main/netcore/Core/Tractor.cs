﻿using System;
using System.Collections.Generic;
using System.Text;

namespace congestion.calculator
{
    public class Tractor : IVehicle
    {
            public String GetVehicleType()
            {
                return "Tractor";
            }
    }    
}
