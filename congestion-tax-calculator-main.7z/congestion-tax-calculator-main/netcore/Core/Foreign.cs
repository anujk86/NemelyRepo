﻿using System;
using System.Collections.Generic;
using System.Text;

namespace congestion.calculator
{
    public class Foreign : IVehicle
    {
        public string GetVehicleType()
        {
            return "Foreign";
        }
    }
}
