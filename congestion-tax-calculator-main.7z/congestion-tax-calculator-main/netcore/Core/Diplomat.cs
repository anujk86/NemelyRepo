﻿using System;
using System.Collections.Generic;
using System.Text;

namespace congestion.calculator
{
    public class Diplomat : IVehicle
    {
        public string GetVehicleType()
        {
            return "Diplomat";
        }
    }
}
