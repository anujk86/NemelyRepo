class Vehicle:
    def get_vehicle_type(self) -> str:
        pass
