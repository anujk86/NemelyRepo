﻿using congestion.calculator;
using System;

namespace ConSoleCongestionTax
{
    internal class Program
    {
        static void Main(string[] args)
        {
            CongestionTaxCalculator ctc = new CongestionTaxCalculator();

            Console.Write("------------- Congestion Tax Calculator ------------\n");
            Console.Write("Motorcycle = 0,\n");
            Console.Write("Tractor = 1,\n");
            Console.Write("Emergency = 2,\n");
            Console.Write("Diplomat = 3,\n");
            Console.Write("Foreign = 4,\n");
            Console.Write("Military = 5,\n");
            Console.Write("Car = 6\n");
            Console.Write("Please select vehicle type - \n");
            var vehicleType = Console.ReadLine();

            IVehicle vObj = VehicleType.GetVehicleType(Convert.ToInt32(vehicleType));

            DateTime[] dt = new DateTime[2];

            Console.WriteLine("Please enter entry date and time in the format of MM.dd.yyyy HH:mm\n");
            dt[0] = DateTime.Parse(Console.ReadLine());
            Console.WriteLine("Please enter exit date and time in the format of MM.dd.yyyy HH:mm \n");
            dt[1] = DateTime.Parse(Console.ReadLine());

            var result = ctc.GetTax(vObj, dt);

            if (result == 0)
            {
                Console.WriteLine("\n No tax applicable.\n");
            }
            else
            {
                Console.WriteLine("\n"+ "Total Tax on Vehicle is :"+result +" SEK");
            }
        }
    }
}
