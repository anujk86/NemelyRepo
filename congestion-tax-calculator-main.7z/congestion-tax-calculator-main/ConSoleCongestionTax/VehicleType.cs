﻿using congestion.calculator;
using System;
using System.Collections.Generic;
using System.Text;

namespace ConSoleCongestionTax
{
    internal class VehicleType
    {
        public static IVehicle GetVehicleType(int vType)
        {
            if (vType == 6)
            {
                return new Car();
            }
            else if (vType == 0)
            {
                return new Motorbike();
            }
            else if (vType == 1)
            {
                return new Tractor();
            }
            else if (vType == 2)
            {
                return new Emergency();
            }
            else if (vType == 3)
            {
                return new Diplomat();
            }
            else if (vType == 4)
            {
                return new Foreign();
            }
            else if (vType == 5)
            {
                return new Military();
            }
            return default;

        }
    }
}
