package congestion.calculator;

import java.util.*;
import java.text.*;

public interface Vehicle {
    String getVehicleType();
}
